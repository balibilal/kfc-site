import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import { CategoriesData } from './CategoriesData';
import "./style.css";



const Categories = () => {
  const [products, setProducts] = useState(CategoriesData);


  return (
    <>
      <div className='container mt-4 mb-4'>
      <br />
        <div className='row'>
          <div className='col-3 text-white'>
            
            <h3>Browse Categories</h3>
            
          </div>
          <div className="col-9 text-white">
            <hr style={{ height: '3px', marginTop: '20px' }} />
          </div>
        </div>
        <br />
        {

          products.map(p =>
            <Link to={`/category/${p.title}`}>
            <div className="card m-2 card-main" style={{width: '18rem', width: '15%', float: 'left'}}>
              <img src={p.image} className="card-img-top" alt="..." />
                <div className="card-body">
                  <h6 className="card-title text-center" style={{fontSize: '13px', fontWeight: 'bold'}}>{p.title}</h6>
                </div>
            </div>
            </Link>
          )
        }
      </div>
    </>
  )
}

export default Categories