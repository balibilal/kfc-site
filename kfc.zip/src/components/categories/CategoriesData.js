import c1 from "../../assets/images/c1.png";
import c2 from "../../assets/images/c2.png";
import c3 from "../../assets/images/c3.png";
import c4 from "../../assets/images/c4.png";
import c5 from "../../assets/images/c5.png";
import c6 from "../../assets/images/c6.png";




export const CategoriesData = [
    {
        id: '1',
        title: 'Everyday Value',
        image: c1
    },
    {
        id: '2',
        title: 'Ala Carte & Combos',
        image: c2
    },
    {
        id: '3',
        title: 'Signature Boxes',
        image: c3
    },
    {
        id: '4',
        title: 'Sharing',
        image: c4
    },
    {
        id: '5',
        title: 'Snacks & Beverages',
        image: c5
    },
    {
        id: '6',
        title: 'Midnight',
        image: c6
    }

]