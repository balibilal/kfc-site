import c1 from "../../assets/images/c1.png";
import c2 from "../../assets/images/c2.png";
import c3 from "../../assets/images/c3.png";
import c4 from "../../assets/images/c4.png";
import c5 from "../../assets/images/c5.png";
import c6 from "../../assets/images/c6.png";


export const CategoryItem = [
    {
        id: '1',
        title: 'Krunch Chicken Combo',
        image: c1,
        category: 'Everyday Value',
        description: '1 Krunch burger + 1 pc of Hot and Crispy Fried Chicken + 1 regular drink',
        price: '460',
    },
    {
        id: '2',
        title: 'Krunch burger',
        image: c6,
        category: 'Ala Carte & Combos',
        description: 'Crunchy chicken fillet, spicy mayo, lettuce, sandwiched between a sesame seed bun',
        price: '260',
    },
    {
        id: '3',
        title: 'Krunch Chicken Combo',
        image: c2,
        category: 'Midnight',
        description: '1 Krunch burger + 1 pc of Hot and Crispy Fried Chicken + 1 regular drink',
        price: '460',
    },
    {
        id: '4',
        title: 'Krunch burger',
        image: c3,
        category: 'Signature Boxes',
        description: 'Crunchy chicken fillet, spicy mayo, lettuce, sandwiched between a sesame seed bun',
        price: '260',
    },
    {
        id: '5',
        title: 'Krunch Chicken Combo',
        image: c4,
        category: 'Sharing',
        description: '1 Krunch burger + 1 pc of Hot and Crispy Fried Chicken + 1 regular drink',
        price: '460',
    },
    {
        id: '6',
        title: 'Krunch burger',
        image: c5,
        category: 'Snacks & Beverages',
        description: 'Crunchy chicken fillet, spicy mayo, lettuce, sandwiched between a sesame seed bun',
        price: '260',
    },



    
]