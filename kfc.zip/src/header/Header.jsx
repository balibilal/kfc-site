import React from 'react'
import logo from "../assets/images/kfc-logo.png";
import bike from "../assets/images/bike.png";
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import RoomIcon from '@mui/icons-material/Room';
import "./style.css";
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';


const Header = () => {
    const count = useSelector((state) => state.count)

    return (
        <>
            <div className='container p-3 header-sec'>
                <Link to='/'>
                    <img src={logo} alt="kfc logo" style={{ width: '70px' }} />
                </Link>
                <div className='bg-secondary start-order'>
                    <div className=''><img src={bike} alt="bike" style={{ width: '30px' }} /></div>
                    <div className=''><h6 className='text-white'>Start an order for delivery</h6></div>
                </div>

                <div className='bg-secondary locations'>
                    <h6 className='text-white mb-0'><RoomIcon style={{ color: '#f00' }} /> Select Location <ArrowDropDownIcon /></h6>
                    <p className='text-white mb-0'>Get accurate pricing and listing</p>
                </div>

                <div className='buttons'>
                        <button className='bucket-button btns-cart' type='button'>
                            <h5 className='text-white mb-0'>{count.bucket}</h5>
                        </button>
                    <button className='btn btn-danger btn-login'>Register/Login</button>
                </div>
            </div>
        </>
    )
}

export default Header