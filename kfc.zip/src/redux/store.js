import {createStore, combineReducers} from 'redux';
import { countReducer } from './reducers/countReducer';
import {bucketReducer} from './reducers/bucketReducer';


const rootReducer = combineReducers({
    count: countReducer,
    bucket: bucketReducer,
})


export const store = createStore(rootReducer);
