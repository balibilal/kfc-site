export const bucketReducer =(state = {bucketItem: []}, action)=>{
    switch(action.type){
        case 'ADDBUCKET':
            return{
                bucketItem:state.bucketItem.action.payload
            }
        case 'MINUSBUCKET':
            return{
                bucketItem:action.payload
            }
        default:
            return state
    }
}