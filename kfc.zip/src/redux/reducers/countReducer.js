export const countReducer =(state = {bucket: 0}, action)=>{
    switch(action.type){
        case 'ADD':
            return{
                bucket:state.bucket+1
            }
        case 'MINUS':
            return{
                bucket:state.bucket-1
            }
        default:
            return state
    }
}