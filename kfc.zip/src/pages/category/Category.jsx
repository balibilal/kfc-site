import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import { CategoriesData } from '../../components/categories/CategoriesData';
import { useParams } from 'react-router-dom'
import { CategoryItem } from '../../components/categoryItem/CategoryItem';
import { useDispatch } from 'react-redux';



const Category = () => {
  const dispatch = useDispatch()
  const { title } = useParams();

  const [products, setProducts] = useState(CategoriesData);
  const prod = CategoryItem.find((p) => p.category == title);

  return (
    <div>

      {

        products.map(p =>
          <Link to={`/category/${p.title}`}>
            <div className="card m-2 card-main" style={{ width: '18rem', width: '15%', float: 'left' }}>
              <div className="card-body">
                <h6 className="card-title text-center" style={{ fontSize: '13px', fontWeight: 'bold' }}>{p.title}</h6>
              </div>
            </div>
          </Link>
        )
      }


      <h1 className='text-white'>{title}</h1>

      <div className="card" style={{ width: '18rem' }}>
        <img src={prod.image} className="card-img-top" alt="..." />
        <div className="card-body">
          <h5 className="card-title">{prod.title}</h5>
          <p className="card-text">{prod.description}</p>
          <div className='row'>
            <div className='col-5' >
              <p className="btn btn-primary" style={{ cursor: 'text' }}>RS:  {prod.price}</p>
            </div>
            <div className='col-7'>
              <Link to="/bucket">
                <button className='btn btn-danger' onClick={()=>dispatch({type:'ADDBUCKET', payload: {prod}})}>Add to bucket</button>
              </Link>
            </div>
          </div>
        </div>
      </div>


    </div>
  )
}

export default Category