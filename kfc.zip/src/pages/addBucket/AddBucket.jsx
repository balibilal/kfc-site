import React from 'react';
import { useSelector } from 'react-redux';



const AddBucket = () => {
const selector = useSelector((state) => state.bucket);
// const [product, setProduct] = useState(selector.bucket);
    console.log(selector.bucketItem.title)
    return (
        <>
            <h1 className='text-white'>lkjhnl</h1>
        </>
    )
}

export default AddBucket