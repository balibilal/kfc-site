import React from 'react'
import Categories from "../../components/categories/Categories";
import HomeSlider from "../../components/homeSlider/HomeSlider";


const Index = () => {
  return (
    <>
        <HomeSlider />
        <Categories />

    </>
  )
}

export default Index