import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Home/Index";

import Header from "./header/Header";
import Category from "./pages/category/Category";
import AddBucket from "./pages/addBucket/AddBucket";

function App() {

  return (
    <>
      <BrowserRouter>
      <Header />
      <Routes>
        <Route path="/" element={<Index />}></Route>
        <Route path="category/:title" element={<Category/>}></Route>
        <Route path="bucket/" element={<AddBucket/>}></Route>

      </Routes>
    </BrowserRouter>
      
    </>
  );
}

export default App;
